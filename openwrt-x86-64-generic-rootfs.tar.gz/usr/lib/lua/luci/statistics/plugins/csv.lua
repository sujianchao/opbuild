return {
	legend = {
		{ "DataDir" },
		{ "StoreRates" },
		{ }
	},
	label = _("CSV Output"),
	category = "output"
}
