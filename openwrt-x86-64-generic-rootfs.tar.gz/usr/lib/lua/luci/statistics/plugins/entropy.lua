return {
	legend = {
		{ },
		{ },
		{ }
	},
	label = _("Entropy"),
	category = "general"
}
