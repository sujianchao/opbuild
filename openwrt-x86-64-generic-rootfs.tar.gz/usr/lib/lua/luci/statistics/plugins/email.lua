return {
	legend = {
		{ "SocketFile", "SocketGroup", "SocketPerms", "MaxConns" },
		{ },
		{ }
	},
	label = _("Email"),
	category = "general"
}
