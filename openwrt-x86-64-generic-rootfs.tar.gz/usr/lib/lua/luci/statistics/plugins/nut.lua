return {
    legend = {
		{ },
		{ },
		{ "UPS" }
	},
	label = _("UPS"),
	category = "general"
}
