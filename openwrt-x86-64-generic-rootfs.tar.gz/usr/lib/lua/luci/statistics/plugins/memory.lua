return {
	legend = {
		{ },
		{ "ValuesPercentage", "ValuesAbsolute" },
		{ }
	},
	label = _("Memory"),
	category = "general"
}
