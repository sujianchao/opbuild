return {
    legend = {
		{ "TTL", "Interval", "AddressFamily" },
		{ },
		{ "Hosts" }
	},
	label = _("Ping"),
	category = "network"
}
