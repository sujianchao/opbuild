return {
	legend = {
		{ },
		{ },
		{ }
	},
	label = _("CPU Frequency"),
	category = "general"
}
