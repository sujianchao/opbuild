return {
	label = _("Network"),
	category = "output"
}
