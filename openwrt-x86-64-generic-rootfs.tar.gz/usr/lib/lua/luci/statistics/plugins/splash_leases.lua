return {
    legend = {
		{ },
		{ },
		{ }
	},
	label = _("Splash Leases"),
	category = "network"
}
