return {
	legend = {
		{ },
		{ "ValuesPercentage" , "ReportByCpu", "ReportByState" },
		{ }
	},
	label = _("Processor"),
	category = "general"
}
