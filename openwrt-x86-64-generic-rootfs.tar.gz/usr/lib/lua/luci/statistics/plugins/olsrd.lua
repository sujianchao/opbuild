return {
    legend = {
		{ "Host", "Port", "CollectLinks","CollectRoutes","CollectTopology"},
		{ },
		{ }
	},
	label = _("OLSRd"),
	category = "network"
}
