return {
    legend = {
		{ "DataDir", "StepSize", "HeartBeat", "RRARows", "XFF", "CacheFlush", "CacheTimeout" },
		{ "RRASingle" },
		{ "RRATimespans" }
	},
	label = _("RRDTool"),
	category = "output"
}
